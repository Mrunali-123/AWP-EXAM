function readvalue(){
    console.log("success");
    let username=document.querySelector("#username").addEventListener;
    document.querySelector("#display").innerHTML=username;
}
function submithere(){
    let username=document.querySelector("#inputid1").nodeValue;
    constnewtelement = document.querySelector("reference comment id");
    clonenode(true);

     newelement.removeattribute(id1);
     newelement.style.visibility="visible";
     newelement.children[0].innerHTML;usersubmit;

     submitbox.insertbefore(newelement);
     submitbox.firstchild1;


}
